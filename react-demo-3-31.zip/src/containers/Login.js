import React from "react";
import {login, logout} from "../actions/auth.action";
import {connect} from "react-redux";

class Login extends React.Component {
    
    constructor(props) {
        super(props);
        console.log(props);
        this.state = {
          user: {
              username: '',
              password: ''
          },
          flag: false // indicate whether clicked on login button
        };
        this.handleInputChange = this.handleInputChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleLogout = this.handleLogout.bind(this);
    }
    
    handleInputChange(event) {
        const {name, value} = event.target;
        // this.state.user[name] = value;
        this.setState({
            user: {
                ...this.state.user,
                [name]: value
            }
        });
    }
    
    handleSubmit(event) {
        event.preventDefault();
        this.setState({
           flag: true
        });
        this.props.login(this.state.user);
        // Q: when does login function finish?
        // A: after user is store will be updated.
        // whenever data is store is updated, Redux will wait for your React
        // codes to finish and then pass down latest data in store to your
        // component for re-render.
        
        // user in store is already updated since Redux flow is synchronous.
        // below codes are React codes. they are executed before
        // React passed down latest value of authUser
        console.log(this.props.authUser); // null???
        // setTimeout( () => {
        //     if (this.props.authUser) { // authUser is not null -> user logged in.
        //         this.props.history.push('/home');
        //     }
        // }, 0);
    }
    
    // want to do something whenever current component props/state changes
    // get new state based on latest props and old state.
    // return new state or return null
    static getDerivedStateFromProps(props, oldState) {
        console.log(props.authUser);
        console.log(oldState);
        // redirect user to login page after user click login button and logged in.
        if (props.authUser && oldState.flag) {
            props.history.push('/home');
        }
        return null;
    }
    
    componentWillUnmount() {
        console.log('before component will be destroyed');
    }
    
    handleLogout(event) {
        event.preventDefault();
        this.props.logout();
    }
    
    render() {
        return (
            <div className="container">
                <h2>Login</h2>
                <form onSubmit={this.handleSubmit}>
                    <div className="form-group">
                        <label>
                            Username
                            <input type="text"
                                   className="form-control"
                                   name="username"
                                   value={this.state.user.username}
                                   onChange={this.handleInputChange}
                            />
                        </label>
                    </div>
                    <div className="form-group">
                        <label>
                            Password
                            <input type="password"
                                   className="form-control"
                                   name="password"
                                   value={this.state.user.password}
                                   onChange={this.handleInputChange}
                            />
                        </label>
                    </div>
                    {
                        this.props.authUser
                            ? <button className="btn btn-danger" type="button" onClick={this.handleLogout}>Logout</button>
                            : <button className="btn btn-primary" type="submit">Login</button>
                    }
                    <p>Logged In User: {JSON.stringify(this.props.authUser)}</p>
                </form>
            </div>
        );
    }
    
}

function mapStateToProps({authUser}) {
    return {authUser};
}

export default connect(mapStateToProps, {login, logout})(Login);
