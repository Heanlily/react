import React from 'react';
import {addNameActionCreator} from "../actions/names.action";
import {connect} from "react-redux";
import {bindActionCreators} from "redux";

class AddName extends React.Component {
    
    // class member variable: changes will not trigger React to generate new virtual DOM tree
    // newName = 'Default';

    constructor(props) {
        super(props); // this.props = props;
        console.log(props);
        // initialize state
        this.state = {
            newName: 'Default'
        };
    }
    
    handleChange(event) {
        // change state, but it will not notify react to generate new virtual dom tree.
        // not the correct way to update state.
        // this.state.newName = event.target.value;
        
        // how to update state?
        // update state + notify React to generate new virtual dom tree.
        this.setState({
            newName: event.target.value
        });

        // newName data is actually updated(Default1), but not reflected on HTML.
        // React is still using the old newName(Default) and reset the HTML to use old newName data.
        // Why???
        // this.forceUpdate(); // magic??? -> inform React that we have new data, please use new data to update DOM tree
    }
    
    handleClick() {
        // this.state.newName
        // call action creator to create an 'ADD_NAME' action with the newName
        // const action = addNameActionCreator(this.state.newName);
        // ask store to dispatch the action to reducer for processing
        // we can't access the store to do the dispatch directly!!!
        
        // use the new action creator
        // create action -> dispatch
        this.props.addNameActionCreatorWithDispatch(this.state.newName);
    }

    render() {
        // this -> an instance of class
        return (
            <React.Fragment>
                <h2>Add A New Name - {this.state.newName}</h2>
                <input type="text" value={this.state.newName} onChange={this.handleChange.bind(this)} />
                <button onClick={this.handleClick.bind(this)}>Add</button>
            </React.Fragment>
        );
    }
    
}

// we don't need any data from store to be pass down, thus we don't mapStateToProps

// we need to ask the redux store to dispatch actions which are created by this component

// receives store's dispatch function
// return new action creators which are bound with the dispatch method,
// and these new action creators will be accessible to current component through props.
function mapDispatchToProps(dispatch) {
    // property name: new action creator name which will be used by component through props
    // property value: old action creator
    return bindActionCreators({
        addNameActionCreatorWithDispatch: addNameActionCreator
    }, dispatch);
}

function mapStateToProps({authUser}) {
    return {authUser};
}


export default connect(mapStateToProps, mapDispatchToProps)(AddName);
