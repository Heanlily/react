import React from "react";
import {Field, reduxForm} from "redux-form";
import {connect} from "react-redux";
import {getProducts} from "../actions/products.action";

const EDIT_RPDOUCTS_FROM_CONTROLS = [
    {name: 'id', type: 'number', label: 'ID'},
    {name: 'name', type: 'text', label: 'Name'},
    {name: 'brand', type: 'text', label: 'Brand'},
    {name: 'price', type: 'number', label: 'Price'},
    {name: 'stock', type: 'number', label: 'Stock'},
    {name: 'image', type: 'text', label: 'Image URL'}
];
class EditProduct extends React.Component{
    
    constructor(props) {
        super(props);
        console.log(props);
    }
    
    componentDidMount() {
        if (!this.props.products) {
            this.props.getProducts();
        }
    }
    
    static getDerivedStateFromProps(props, oldState) {
        // products: null -> [8]
        if (!props.initialized && props.products !== null) {
            // find the product and use its value to initialize form
            const id = +props.match.params.id;
            const product = props.products.find(p => p.id === id);
            props.initialize(product);
        }
        return null;
    }
    
    // functional component
    renderFC(props) {
        // console.log(props);
        const {input, meta, type, label} = props;
        // input: name, value, some event listener created by redux-form
        // meta: form control state. e.g. valid, touched, submitted, dirty, error,...
        return (
            <div className="form-group">
                <label>
                    {label}
                    <input type={type}
                        className="form-control"
                        {...input}
                        disabled={input.name === 'id'}
                    />
                </label>
                <p className="text-danger">{meta.error}</p>
            </div>
        );
    }
    
    // click on submit button
    // get user's input in all fields and prevent page to be refreshed.
    mySubmit = (value) => {
        console.log(value);
    };
    
    render() {
        return (
            <div className="container">
                <h2>Edit Product - {this.props.match.params.id}</h2>
                <form onSubmit={this.props.handleSubmit(this.mySubmit)}>
                    {
                        EDIT_RPDOUCTS_FROM_CONTROLS.map(fc => {
                            return <Field
                                    component={this.renderFC}
                                    {...fc}
                                    />;
                        })
                    }
                    <button type="submit" className="btn btn-primary">Submit</button>
                </form>
            </div>
        )
    }
    
}

function mapStateToProps({products, form}) {
    console.log('form:', form);
    return {products};
}

function validate(value) {
    const errors = {};
    
    if (!value.name) {
        errors.name = 'Name must be provided!';
    } else if (value.name.length < 3) {
        errors.name = 'Name must be more than 2 characters!'
    }
    
    if (value.price < 0) {
        errors.price = 'Price must be a non-negative value!'
    }
    
    return errors;
}

// decorator
// EditProduct -> redux connected EditProduct
// -> redux-form connected redux connected EditProduct
export default reduxForm({
    form: 'EditProductForm',
    validate
})(
    connect(mapStateToProps, {getProducts})(EditProduct)
);
