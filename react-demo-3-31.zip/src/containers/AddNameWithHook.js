import React, {useEffect, useState} from "react";
import {addNameActionCreator} from "../actions/names.action";
import {useDispatch} from "react-redux";

// can't use this.state
export default function AddNameWithHook() {
    // newName: reference to state
    // setNewName: function to update newName state. invoke this function will trigger
    // component to render
    const [newName, setNewName] = useState('Jack'); // [state, function]
    const dispatch = useDispatch(); // get reference of store's dispatch function
    const [newBook, setNewBook] = useState('Java');
    
    const handleChange = (event) => setNewName(event.target.value);
    const handleChangeBook = (event) => setNewBook(event.target.value);
    const handleClick = () => {
        const action = addNameActionCreator(newName);
        dispatch(action);
    };
    
    // useEffect
    useEffect(() => {
        console.log('useEffect is invoked!');
    }, [newName]);
    
    // componentWillUnmount
    useEffect(() => {
        return () => {
            console.log('useEffect is invoked before component will be destroyed!');
        };
    }, []);
    
    
    return (
        <React.Fragment>
            <h2>Add A New Name (Hook)- {newName} - {newBook}</h2>
            <input type="text" value={newName} onChange={handleChange} />
            <input type="text" value={newBook} onChange={handleChangeBook} />
            <button onClick={handleClick}>Add</button>
        </React.Fragment>
    );
}
