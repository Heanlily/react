import React from 'react';
import {connect} from "react-redux";
import {bindActionCreators} from "redux";
import {addProduct} from "../actions/products.action";

const ADD_RPDOUCTS_FROM_CONTROLS = [
    {name: 'id', type: 'number', label: 'ID'},
    {name: 'name', type: 'text', label: 'Name'},
    {name: 'brand', type: 'text', label: 'Brand'},
    {name: 'price', type: 'number', label: 'Price'},
    {name: 'stock', type: 'number', label: 'Stock'},
    {name: 'image', type: 'text', label: 'Image URL'}
];
class AddProduct extends React.Component {
    
    constructor(props) {
        super(props);
        this.state = {
            newProduct: {
                id: 0,
                name: '',
                brand: '',
                price: 0,
                stock: 0,
                image: ''
            }
        };
        
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleChange = this.handleChange.bind(this);
    }
    
    renderField({name, type, label}) {
        return (
            <div className="form-group" key={name}>
                <label>
                    {label}
                    <input
                        type={type}
                        className="form-control"
                        name={name}
                        value={this.state.newProduct[name]}
                        onChange={this.handleChange}
                    />
                </label>
            </div>
        );
    }
    
    handleChange(event) {
        const {name, value} = event.target;
        this.state.newProduct[name] = value;
        this.setState({
            newProduct: this.state.newProduct
        });
    }
    
    handleSubmit(event) {
        // prevent default behaviors: submit form to action url and reload page.
        event.preventDefault();
        console.log(this.state.newProduct);
        // deep clone. why??? try to use stay on the add product component and add two products
        // you will find the previous added product will be changed to second one's
        // reason: stay on same page, you are adding same reference of this.state.product to products
        // array in store. that's why you need to make a copy.
        this.props.addProduct(JSON.parse(JSON.stringify(this.state.newProduct)));
    }
    
    render() {
        return (
            <div className="container">
                <h2>Add Product</h2>
                <form onSubmit={this.handleSubmit}>
                    {
                        ADD_RPDOUCTS_FROM_CONTROLS.map(field => this.renderField(field))
                    }
                    <button className="btn btn-primary" type="submit">Add</button>
                </form>
            </div>
        );
    }
    
}

// syntax sugar for mapDispatchToProps

// function mapDispatchToProps(dispatch) {
//     return bindActionCreators({
//         addProduct: addProduct
//     }, dispatch);
// }

// {addProduct: addProduct} -> {addProduct}
export default connect(null, {addProduct})(AddProduct);
