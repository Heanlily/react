import React from "react";
import ReactDOM from 'react-dom';
import Name from "./components/Name";
import Names from "./components/Names";
import App from "./components/App";
import 'bootstrap/dist/css/bootstrap.min.css';
import {Provider} from "react-redux";
import {applyMiddleware, createStore} from "redux";
import rootReducer from "./reducers/root.reducer"; // Webpack
import reduxPromise from 'redux-promise';

const data = 'Hello React';

// use js to dynamically add <h2> to div#root
// DOM API
// const h2DOMElem = document.createElement('h2');
// const h2Text = document.createTextNode(data);
// h2DOMElem.appendChild(h2Text);
// document.getElementById('root').appendChild(h2DOMElem);

// React way
// React Element: smallest unit. React representation of DOM element.
// React Element -> DOM element
// const h2ReactElement = React.createElement('h2', null, data);
// JSX = JS + HTML
// {js}
// const h2ReactElement = <h2>{data}</h2>;
// ReactDOM.render(h2ReactElement, document.getElementById('root'));

// apply reduxPromise middleware to redux store,
// thus all the actions dispatched by the store will be pre-process by this middleware.
const store = createStore(rootReducer, applyMiddleware(reduxPromise));

ReactDOM.render(
    <Provider store={store}>
        <App />
    </Provider>, document.getElementById('root'));
