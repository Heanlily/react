// combine all the reducers together in order to build one single store.
// multiple reducers -> root reducer -> store

import {combineReducers} from "redux";
import namesReducer from "./names.reducer";
import productsReducer from "./products.reducer";
import authReducer from "./auth.reducer";
import {reducer as formReducer} from "redux-form";

// property name: name of data in store
// property value: reference of the reducer to provide data
const rootReducer = combineReducers({
    names: namesReducer,
    products: productsReducer,
    authUser: authReducer,
    form: formReducer // redux-form will use formReducer to manage the "form" data in store.
});

export default rootReducer;
