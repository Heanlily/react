import {LOGIN, LOGOUT} from "../actions/auth.action";

const USERS = [
    {id: 1, username: 'bob', password: 'bob123'},
    {id: 2, username: 'alice', password: 'alice456'},
    {id: 3, username: 'alex', password: 'alex666'},
];

export default function authReducer(oldState = null, action) {
    switch (action.type) {
        case LOGIN:
            const user = action.payload;
            const found = USERS.find(u => u.username === user.username && u.password === user.password);
            return found || oldState;
        case LOGOUT:
            return null;
        default:
            return oldState;
    }
}
