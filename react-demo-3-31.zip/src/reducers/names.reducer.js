// receives old names data in the store
// return new names data you want to set in store.
const NAMES = ['Bob', 'Alex', 'Alice', 'Tom', 'Cathy'];
export default function namesReducer(oldNamesInStore = NAMES, action) {
    // if (oldNamesInStore === undefined) {
    //     return ['Bob', 'Alex', 'Alice']; // initialize names in store.
    // }
    
    switch (action.type) {
        case 'ADD_NAME':
            return [...oldNamesInStore, action.payload];
        case 'DELETE_NAME':
            const nameToDelete = action.payload;
            const index = oldNamesInStore.findIndex(name => name === nameToDelete);
            oldNamesInStore.splice(index, 1);
            return [...oldNamesInStore]; // make a copy
        default:
            return oldNamesInStore;
    }
}

// we use namesReducer to initialize names data in store.
