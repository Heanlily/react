import {ADD_PRODUCT, GET_PRODUCTS} from "../actions/products.action";

const PRODUCTS = [
    {
        id: 1, name: 'iPhone', brand: 'Apple', price: 100, stock: 22,
        image: 'https://s3.us-east-2.amazonaws.com/msi-tech-2019/iphone.jpg'
    },
    {
        id: 2, name: 'iPhone3G', brand: 'Apple', price: 200, stock: 33,
        image: 'https://s3.us-east-2.amazonaws.com/msi-tech-2019/iphone3G.jpg'
    },
    {
        id: 3, name: 'iPhone3GS', brand: 'Apple', price: 300, stock: 11,
        image: 'https://s3.us-east-2.amazonaws.com/msi-tech-2019/iphone3GS.jpg'
    },
    {
        id: 4, name: 'iPhone4', brand: 'Apple', price: 400, stock: 22,
        image: 'https://s3.us-east-2.amazonaws.com/msi-tech-2019/iphone4.jpg'
    },
    {
        id: 5, name: 'iPhone4S', brand: 'Apple', price: 500, stock: 33,
        image: 'https://s3.us-east-2.amazonaws.com/msi-tech-2019/iphone4S.jpg'
    },
    {
        id: 6, name: 'iPhone5', brand: 'Apple', price: 600, stock: 11,
        image: 'https://s3.us-east-2.amazonaws.com/msi-tech-2019/iphone5.jpeg'
    },
    {
        id: 7, name: 'iPhone5C', brand: 'Apple', price: 700, stock: 222,
        image: 'https://s3.us-east-2.amazonaws.com/msi-tech-2019/iphone5c.png'
    },
    {
        id: 8, name: 'iPhone5S', brand: 'Apple', price: 800, stock: 333,
        image: 'https://s3.us-east-2.amazonaws.com/msi-tech-2019/iphone5s.jpg'
    },
    {
        id: 9, name: 'iPhone6', brand: 'Apple', price: 900, stock: 111,
        image: 'https://s3.us-east-2.amazonaws.com/msi-tech-2019/iphone6.jpg'
    },
];

export default function productsReducer(oldState = null, action) {
    switch (action.type) {
        case ADD_PRODUCT:
            return [...oldState, action.payload];
        case GET_PRODUCTS:
            console.log(action.payload);
            // if action.payload is a promise,
            // then productsReducer will not wait for the promise to be resolved.
            // thus we can't use the products from promise as new data in store.
            return action.payload.data; // get data from resolved promise.
        default:
            return oldState;
    }
}
