// action creators for names

export function addNameActionCreator(newName) {
    return {
        type: 'ADD_NAME',
        payload: newName
    };
}

export function deleteNameActionCreator(nameToDelete) {
    return {
        type: 'DELETE_NAME',
        payload: nameToDelete
    };
}
