import axios from 'axios';

export const ADD_PRODUCT = 'ADD_PRODUCT';
export const GET_PRODUCTS = 'GET_PRODUCTS';

export function addProduct(newProduct) {
    return {
        type: ADD_PRODUCT,
        payload: newProduct
    };
}

// send AJAX request to server and get products as payload
export function getProducts() {
    let promise = axios.get('http://localhost:8080/products');
    return {
        type: GET_PRODUCTS,
        payload: promise
    };
}
