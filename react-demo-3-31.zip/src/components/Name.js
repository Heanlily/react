import React from 'react'; // JSX

// create a Name component which can display user's name in blue color.

// a functional component: create a function which returns React element(s)
// props: contains all data which are passed down from parent component
// this.props
export default function Name(props) { // {name: 'Bob'}
    const name = props.name;
    const styles = {
      color: 'blue'
    };
    return <span style={styles}>{name}</span>;
}
