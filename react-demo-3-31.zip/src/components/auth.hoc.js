import React from "react";
import {connect} from "react-redux";

// High order component
// add Route Protection to any existing component without modifying it.

export default function auth(ExistingComponent) {
    // wrap existing component in another component
    
    class WrapperComponent extends React.Component {
        
        state = {};
    
        static getDerivedStateFromProps(props, state) {
            if (!props.authUser) {
                props.history.push('/login');
            }
            return null;
        }
        
        render() {
            // return <ExistingComponent
            //             history={this.props.history}
            //             location={this.props.location}
            //             match={this.props.match}
            // />;
            return <ExistingComponent {...this.props} />;
        }
    
    }
    
    function mapStateToProps({authUser}) {
        return {authUser};
    }
    
    return connect(mapStateToProps)(WrapperComponent);
}

// AddName
// auth(AddName) => WrapperComponent
