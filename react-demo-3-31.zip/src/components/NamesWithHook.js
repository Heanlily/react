import React from "react";
import Name from "./Name";
import {useSelector} from "react-redux";

export default function NamesWithHook(props) {
    // select names from redux store
    const names = useSelector(store => store.names); // mapStateToProps
    return (
        <React.Fragment>
            <h2>Names (Hook)</h2>
            <ul>
                {
                    names && names.map(n => {
                        return (
                            <li key={n}>
                                <Name name={n} />
                            </li>
                        );
                    })
                }
            </ul>
        </React.Fragment>
    )
}
