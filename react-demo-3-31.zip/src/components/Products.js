import React from 'react';
import {connect} from "react-redux";
import {getProducts} from "../actions/products.action";
import {Link} from "react-router-dom";

class Products extends React.Component {
    
    componentDidMount() {
        // invoke an action creator which will send AJAX request
        // to server for loading products data.
        this.props.getProducts();
    }
    
    render() {
        return (
            <div className="container">
                <h2>Products</h2>
                <table className="table table-bordered table-striped">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Brand</th>
                        <th>Price</th>
                        <th>Stock</th>
                        <th>Image</th>
                    </tr>
                    </thead>
                    <tbody>
                    {
                        this.props.products && this.props.products.map(p => {
                            return (
                                <tr key={p.id}>
                                    <td>{p.id}</td>
                                    <td>
                                        <Link to={`/edit-product/${p.id}`}>
                                            {p.name}
                                        </Link>
                                    </td>
                                    <td>{p.brand}</td>
                                    <td>{p.price}</td>
                                    <td>{p.stock}</td>
                                    <td>
                                        <img src={p.image} style={{width: '160px', height: '160px'}} />
                                    </td>
                                </tr>
                            );
                        })
                    }
                    </tbody>
                </table>
            </div>
        );
    }
    
}

function mapStateToProps({products}) {
    return {products};
}

export default connect(mapStateToProps, {getProducts})(Products);
