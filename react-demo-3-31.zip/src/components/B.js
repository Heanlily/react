import React from "react";
import NameContext from "../contexts/name.context";

class B extends React.Component{
    
    static contextType = NameContext;
    
    render() {
        const styles = {
            border: '1px dotted red',
            width: '100px',
            height: '50px'
        };
        return (
            <div style={styles}>
                B
                <p>
                    name: {this.context}
                </p>
                <p>
                    <NameContext.Consumer>
                        {value => <span>name: {value}</span>}
                    </NameContext.Consumer>
                </p>
            </div>
        );
    }
    
}

export default B;
