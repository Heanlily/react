import React from 'react';
import Name from "./Name";
import {connect} from "react-redux";
import {bindActionCreators} from "redux";
import {deleteNameActionCreator} from "../actions/names.action";

// create a Names component to display array of names
// class based component

class Names extends React.Component{
    
    handleClick(nameToDelete) {
        this.props.deleteNameActionCreatorWithDispatch(nameToDelete);
    }
    
    render() {
        // this.props
        // single-root rule: returned react elements must be under
        // a single root React element.
        // must use {} to wrap js in jsx!!!
        return (
            <React.Fragment>
                <h2>Names</h2>
                <ul>
                    {
                        this.props.names && this.props.names.map(n => {
                            return (
                                <li key={n}>
                                    <Name name={n} />
                                    <button className="btn btn-link" onClick={() => this.handleClick(n)}>Delete</button>
                                </li>
                            );
                        })
                    }
                </ul>
            </React.Fragment>
        );
    }
    
}

// Decorator Design Pattern : add additional functionality to existing class without modifying the class
// Names Component -> Redux-connected Names Component

// specify which part of store should be passed down to current component
// since current component doesn't need all the data in store.
function mapStateToProps(store) { // entire application state
    // return an object to specify which part of the store
    // will be passed to current component props.
    // property name: name of props to receive data in component
    // property value: data from store.
    return {
        names: store.names
    };
}

function mapDispatchToProps(dispatch) {
    return bindActionCreators({
        deleteNameActionCreatorWithDispatch: deleteNameActionCreator
    }, dispatch);
}

const ReduxConnectedNames = connect(mapStateToProps, mapDispatchToProps)(Names);
export default ReduxConnectedNames;
