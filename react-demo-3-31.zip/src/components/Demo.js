import React from "react";
import Name from "./Name";
import A from "./A";
import NameContext from "../contexts/name.context";

class Demo extends React.Component {
    
    constructor(props) {
        super(props);
        this.pRef = React.createRef();
        this.nRef = React.createRef();
        
        this.state = {
            name: ''
        }
    }
    
    handleChange = (event) => {
        this.setState({
           name: event.target.value
        });
    };
    
    handleClick = () => {
        // select the paragraph and change color
        this.pRef.current.style.color = 'red';
        console.log(this.nRef);
    };
    
    render() {
        return (
          <div>
              <p ref={this.pRef}>Some contents...</p>
              <Name name="Bob" ref={this.nRef} />
              <p>
                  <button onClick={this.handleClick}>Change Color</button>
              </p>
              <p>
                  Enter Your Name: <input type="text" value={this.state.name} onChange={this.handleChange}/>
              </p>
              <NameContext.Provider value={this.state.name}>
                <A/>
              </NameContext.Provider>
          </div>
        );
    }
    
}

export default Demo;
