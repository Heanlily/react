import React from 'react';
import Names from "./Names";
import AddName from "../containers/AddName";
import {BrowserRouter, Route, Switch} from "react-router-dom";
import Home from "./Home";
import Products from "./Products";
import AddProduct from "../containers/AddProduct";
import Login from "../containers/Login";
import Header from "./Header";
import auth from "./auth.hoc";
import EditProduct from "../containers/EditProduct";
import Demo from "./Demo";
import AddNameWithHook from "../containers/AddNameWithHook";
import NamesWithHook from "./NamesWithHook";

export default class App extends React.Component {
    
    // names = ['Bob', 'Alex', 'Alice'];
    
    constructor(props) {
        super(props);
        // this.state = {
        //     names: ['Bob', 'Alex', 'Alice']
        // };
    }
    
    // addNewName(newName) {
    //     // this.names.push(newName);
    //     // this.forceUpdate();
    //     this.setState({
    //         names: [...this.state.names, newName]
    //     });
    // }
    
    render() {
        // virtual root element: will not be rendered in DOM tree.
        return (
            <React.Fragment>
                {/*<Names names={this.state.names}/>*/}
                {/*<AddName addNewName={this.addNewName.bind(this)} />*/}
                
                <BrowserRouter>
                    <Header/>
                    <Switch>
                        <Route path="/names" component={NamesWithHook}/>
                        <Route path="/add-name" component={AddNameWithHook} />
                        <Route path="/products" component={Products} />
                        <Route path="/add-product" component={auth(AddProduct)} />
                        <Route path="/login" component={Login} />
                        <Route path="/edit-product/:id" component={EditProduct} />
                        <Route path="/demo" component={Demo} />
                        <Route path="/" component={Home} />
                    </Switch>
                </BrowserRouter>
            </React.Fragment>
        );
    }
    
}
