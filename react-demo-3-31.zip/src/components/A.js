import React from "react";
import B from "./B";

class A extends React.Component{
    
    render() {
        const styles = {
            border: '1px solid blue',
            width: '200px',
            height: '100px',
            padding: '10px'
        };
        return (
            <div style={styles}>
                A
                <B />
            </div>
        );
    }
    
}

export default A;
