import React from "react";
import {connect} from "react-redux";

class Home extends React.Component {
    
    render() {
        return (
            <React.Fragment>
                <h2>Welcome!!! {JSON.stringify(this.props.authUser)}</h2>
                <p>Total names: {this.props.names && this.props.names.length}</p>
            </React.Fragment>
        );
    }
    
}

function mapToStateToProps(store) {
    return {
        names: store.names,
        authUser: store.authUser
    };
}

export default connect(mapToStateToProps)(Home);
